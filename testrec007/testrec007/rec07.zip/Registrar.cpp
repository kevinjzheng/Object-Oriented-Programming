//
//  Registrar.cpp
//  testrec007
//
//  Created by Kevin J. Zheng on 10/18/18.
//  Copyright © 2018 Kevin J. Zheng. All rights reserved.
//

#include "Registrar.h"
#include "Student.h"
#include "Courses.h"

#include <string>
#include <iostream>
#include <vector>
using namespace std;

namespace BrooklynPoly {
    ostream& operator<<(ostream& os, const Registrar& registrar) {
        for (size_t i = 0; i < registrar.courses.size(); i++) {
            cout << *(registrar.courses[i]) << endl;
        }
        cout << "Students: \n";
        for (size_t j = 0; j < registrar.students.size(); j++) {
            cout << "\t" << *(registrar.students[j]) << endl;
        }
        return os;
    }

    Registrar::Registrar() { }
    bool Registrar::addCourse(const string& courseName) {
        if (findCourse(courseName) != courses.size()) {
            cerr << "Course already exists: " << courseName << endl;
            return false;
        }
        Course* newCourse = new Course(courseName);
        courses.push_back(newCourse);
        return true;
    }
    bool Registrar::addStudent(const string& studentName) {
        if (findStudent(studentName) != students.size()) {
            cerr << "Student already exists: " << studentName << endl;
            return false;
        }
        Student* newStudent = new Student(studentName);
        students.push_back(newStudent);
        return true;
    }
    bool Registrar::enrollStudentInCourse(const string& studentName,
                                          const string& courseName) {
        if (findStudent(studentName) == students.size() or
            findCourse(courseName) == courses.size()) {
            cerr << "Student or Course Does Not Exist, cannot enroll!" << endl;
            return false;
        }
        size_t studentIndex = findStudent(studentName);
        size_t courseIndex = findCourse(courseName);
        students[studentIndex]->addCourse(courses[courseIndex]);
        courses[courseIndex]->addStudent(students[studentIndex]);
        return true;
    }
    bool Registrar::cancelCourse(const string& courseName) {
        if (findCourse(courseName) == courses.size()) {
            cerr << "Course does not exist, cannot be cancelled!" << endl;
            return false;
        }
        Course * temp;
        temp = courses[findCourse(courseName)];
        courses[findCourse(courseName)] = courses[courses.size() - 1];
        temp->purge();
        delete temp;
//        courses[courses.size() - 1] = temp;
//        courses[courses.size() - 1]->purge();
//        delete courses[courses.size() - 1];
        courses.pop_back();
        return true;
    }
    size_t Registrar::findStudent(const std::string& studentName) {
        for (size_t i = 0; i < students.size(); i++) {
            if (students[i]->getName() == studentName) {
                return i;
            }
        }
        return students.size();
    }
    size_t Registrar::findCourse(const std::string& courseName) {
        for (size_t i = 0; i < courses.size(); i++) {
            if (courses[i]->getName() == courseName) {
                return i;
            }
        }
        return courses.size();
    };
    void Registrar::purge() {
        for (size_t i = 0; i < courses.size(); i++) {
            courses[i]->purge();
            delete courses[i];
        }
        for (size_t j = 0; j < students.size(); j++) {
            delete students[j];
        }
        courses.clear();
        students.clear();
    }
}
