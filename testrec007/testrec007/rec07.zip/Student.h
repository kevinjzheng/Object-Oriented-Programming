//
//  Student.hpp
//  testrec007
//
//  Created by Kevin J. Zheng on 10/18/18.
//  Copyright © 2018 Kevin J. Zheng. All rights reserved.
//

#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include <vector>
#include <iostream>

namespace BrooklynPoly {
    class Course;   // forward class declaration

    class Student {
        friend std::ostream& operator<<(std::ostream& os, const Student& stu);
    public:
        Student(const std::string& name);
        std::string getName() const;
        void addCourse(Course*);
        std::vector<Course*> getCourses();
        void removeCourse(Course*);
    private:
        std::string name;
        std::vector<Course*> courses;
    };
}
#endif /* STUDENT_H */
